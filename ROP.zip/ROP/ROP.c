#include <string.h>
#include <stdio.h>

int main(int argc, char * argv[])
{
	char buff[4];

	gets(buff);

	return 0;
}
