#!/bin/bash

gcc -m32 -fno-stack-protector -g -O0 check_passwd1.c -o check_passwd1
