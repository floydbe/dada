echo You passed your OWLs. You are a true Wizard!  Congratulations!
