#include <stdio.h>

int VirusCode() {
   printf ("You have been infected with the Cavman virus!\n");
   return 0;
}

